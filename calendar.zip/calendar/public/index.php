<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php include("../includes/layouts/header.php"); ?>
<?php find_selected_page(true); ?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
		<?php echo public_navigation($current_subject, $current_page); ?>
	</div>
	<div id="page">
		<?php if ($current_page["menu_name"] == "View Calendar") {
			redirect_to("view_events.php");
		}
		if ($current_page["menu_name"] == "Manage Events") {
			redirect_to("manage_events.php");
		}
		if ($current_page["menu_name"] == "View Shifts") {
			redirect_to("view_shifts.php");
		}
		if ($current_page["menu_name"] == "Details") {
			redirect_to("view_account.php");
		}
		if ($current_page["menu_name"] == "Logout") {
			redirect_to("logout.php");
		}?>
		
		<?php if ($current_page) { ?>
			
			<h2><?php echo htmlentities($current_page["menu_name"]); ?></h2>
			<?php echo nl2br(htmlentities($current_page["content"])); ?>
			
			<?php } else { ?>
			<h2>Home Page</h2>
			<p>Welcome to the home page, <?php echo htmlentities($_SESSION["username"]); ?>.</p>
			<p>Use the navigation area to the left to view events and station cleaning schedules, or manage your account.</p>
			<br />
			<?php 
				$user = find_user_by_username($_SESSION["username"]);
				if ($user["administrator"] == 1) 
				{
				?><p><a href="admin.php">Admin Area</a></p>
				<?php
				}
			} 
		?>
	</div>
</div>
<?php include("../includes/layouts/footer.php"); ?>