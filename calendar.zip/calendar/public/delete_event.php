<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	confirm_logged_in(); 
?>

<?php
	$event = find_event_by_id($_GET["id"]);
	if (!$event) {
		// Event ID was missing or invalid or 
		// event couldn't be found in database
		$_SESSION["message"] = "Couldn't find events.";
		redirect_to("manage_events.php");
	}
	
	$id = $event["id"];
	$query = "DELETE FROM events WHERE id = {$id} LIMIT 1";
	$result = mysqli_query($connection, $query);
	
	if ($result && mysqli_affected_rows($connection) == 1) {
		// Success
		$_SESSION["message"] = "Event deleted.";
		redirect_to("manage_events.php");
		} else {
		// Failure
		$_SESSION["message"] = "Event deletion failed.";
	}
?>
