<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	confirm_logged_in(); 
?>

<?php
	$event = find_event_by_id($_GET["id"]);
	if (!$event) {
		// Event ID was missing or invalid or 
		// event couldn't be found in database
		$_SESSION["message"] = "Couldn't find events.";
	}
?>

<?php
	$id = $event["id"];
	$users_joined = $event["users_joined"];
	$logged_in_user = $_SESSION["username"];
	
	if($event["number_joined"] < $event["number_requested"]) {
		
//		if($users_joined = null || $users_joined == '_') {
//			$query = "UPDATE events SET users_joined = '_' WHERE id = '{$id}'";
//			$result = mysqli_query($connection, $query);
//		}
		$query  = "UPDATE events SET ";
		$query .= "number_joined = number_joined + 1, ";
		$query .= "users_joined = CONCAT_WS('_', '{$users_joined}', '{$logged_in_user}'), ";
		$query .= "WHERE id = '{$id}' ";
		$query .= "LIMIT 1";
		$result = mysqli_query($connection, $query);
	}
	
	if ($result && mysqli_affected_rows($connection) == 1) {
		// Success
		$_SESSION["message"] = "Event joined.";
		redirect_to("view_events.php");
		} else {
		// Failure
		$_SESSION["message"] = "Event not joined.";
		redirect_to("view_events.php");
	}
?>