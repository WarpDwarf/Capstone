<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php
	$shift = find_shift_by_id($_GET["id"]);
	
	if (!$shift) {
		// Shift ID was missing or invalid or 
		// shift couldn't be found in database
		redirect_to("manage_shifts.php");
	}
?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		if (empty($errors)) {
			
			// Perform Update
			
			$id = $shift["id"];
			$date = mysql_prep($_POST["date"]);
			$D = mysql_prep($_POST["D"]);
			$O = mysql_prep($_POST["O"]);
			$FF1 = mysql_prep($_POST["FF1"]);
			$FF2 = mysql_prep($_POST["FF2"]);
			
			$query  = "UPDATE shifts SET ";
			$query .= "date = '{$date}', ";
			$query .= "D = '{$D}', ";
			$query .= "O = '{$O}', ";
			$query .= "FF1 = '{$FF1}', ";
			$query .= "FF2 = '{$FF2}' ";
			$query .= "WHERE id = '{$id}' ";
			$query .= "LIMIT 1";
			$result = mysqli_query($connection, $query);
			
			if ($result && mysqli_affected_rows($connection) == 1) {
				// Success
				$_SESSION["message"] = "Shift updated.";
				redirect_to("manage_shifts.php");
				} else {
				// Failure
				$_SESSION["message"] = "Shift update failed, or no changes detected.";
			}
			
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>

<div id="main">
	<div id="navigation">
		&nbsp;
	</div>
	<div id="page">
		<?php echo message(); ?>
		<?php echo form_errors($errors); ?>
		
		<h2>Edit Shift</h2>
		<form action="edit_shift.php?id=<?php echo urlencode($shift["id"]); ?>" method="post">
			<p>Date:
				<input type="text" name="date" value="<?php echo htmlentities($shift["date"]); ?>" />
			</p>
			<p>D:
				<input type="text" name="D" value="<?php echo htmlentities($shift["D"]); ?>" />
			</p>
			<p>O:
				<input type="text" name="O" value="<?php echo htmlentities($shift["O"]); ?>" />
			</p>
			<p>FF1:
				<input type="text" name="FF1" value="<?php echo htmlentities($shift["FF1"]); ?>" />
			</p>
			<p>FF2:
				<input type="text" name="FF2" value="<?php echo htmlentities($shift["FF2"]); ?>" />
			</p>
			<input type="submit" name="submit" value="Edit Shift" />
		</form>
		<br />
		<a href="manage_shifts.php"><input type="button" name="cancel" value="Cancel" /></a>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
