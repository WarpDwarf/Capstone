<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php $shift_set = find_all_shifts(); ?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>
<div id="main">
	<div id="navigation">
		<br />
		<a href="admin.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<?php echo message(); ?>
		<h2>Manage Shifts</h2>
		<table>
			<tr>
				<th style="text-align: left; width: 100px;">Shift Date</th>
				<th style="text-align: left; width: 100px;">D</th>
				<th style="text-align: left; width: 100px;">O</th>
				<th style="text-align: left; width: 100px;">FF</th>
				<th style="text-align: left; width: 100px;">FF</th>
				<th colspan="2" style="text-align: left;">Actions</th>
			</tr>
			<?php while($shift = mysqli_fetch_assoc($shift_set)) { ?>
				<tr>
					<td><?php echo htmlentities($shift["date"]); ?></td>
					<td><?php echo htmlentities($shift["D"]); ?></td>
					<td><?php echo htmlentities($shift["O"]); ?></td>
					<td><?php echo htmlentities($shift["FF1"]); ?></td>
					<td><?php echo htmlentities($shift["FF2"]); ?></td>
					<td><a href="edit_shift.php?id=<?php echo urlencode($shift["id"]); ?>">Edit</a></td>
					<td><a href="delete_shift.php?id=<?php echo urlencode($shift["id"]); ?>" onclick="return confirm('Are you sure?');">Delete</a></td>
				</tr>
			<?php } ?>
		</table>
		<br />
		<a href="new_shift.php">Add new shift</a>
	</div>
</div>
<?php include("../includes/layouts/footer.php"); ?>
