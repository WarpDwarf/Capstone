<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	confirm_logged_in();
	$shift_set = find_all_shifts();
?>

<?php
	$layout_context = "public";
	include("../includes/layouts/header.php"); 
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<h2>Shifts</h2>
		<?php echo message(); ?>
		<table>
			<tr>
				<th style="text-align: left; width: 100px;">Date</th>
				<th style="text-align: left; width: 100px;">D</th>
				<th style="text-align: left; width: 100px;">O</th>
				<th style="text-align: left; width: 100px;">FF</th>
				<th style="text-align: left; width: 100px;">FF</th>
			</tr>
			<?php while($shift = mysqli_fetch_assoc($shift_set)) { ?>
				<tr>
					<td><?php echo htmlentities($shift["date"]); ?></td>
					<td><?php echo htmlentities($shift["D"]); ?></td>
					<td><?php echo htmlentities($shift["O"]); ?></td>
					<td><?php echo htmlentities($shift["FF1"]); ?></td>
					<td><?php echo htmlentities($shift["FF2"]); ?></td>
				</tr>
			<?php } ?>
		</table>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
