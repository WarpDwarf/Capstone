<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	confirm_logged_in();
	$event_set = find_all_events();
?>

<?php
	$layout_context = "public";
	include("../includes/layouts/header.php"); 
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<h2>Events</h2>
		<?php echo message(); ?>
		<table>
			<tr>
				<th style="text-align: left; width: 100px;">Event Name</th>
				<th style="text-align: left; width: 100px;">Location</th>
				<th style="text-align: left; width: 100px;">Date</th>
				<th style="text-align: left; width: 120px;">Time</th>
				<th style="text-align: left; width: 100px;">Requested</th>
				<th style="text-align: left; width: 100px;">Joined</th>
				<th colspan="3" style="text-align: left;">Actions</th>
			</tr>
			<?php while($event = mysqli_fetch_assoc($event_set)) { ?>
				<tr>
					<td><?php echo htmlentities($event["event_name"]); ?></td>
					<td><?php echo htmlentities($event["location"]); ?></td>
					<td><?php echo htmlentities($event["event_date"]); ?></td>
					<td><?php echo htmlentities($event["event_time"]); ?></td>
					<td><?php echo htmlentities($event["number_requested"]); ?></td>
					<td><?php echo htmlentities($event["number_joined"]); ?></td>
					<td><a href="view_event.php?id=<?php echo urlencode($event["id"]); ?>">View</a></td>
					<td><a href="join_event.php?id=<?php echo urlencode($event["id"]); ?>">Join</a></td>
					<td><a href="leave_event.php?id=<?php echo urlencode($event["id"]); ?>">Leave</a></td>
				</tr>
			<?php } ?>
		</table>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
