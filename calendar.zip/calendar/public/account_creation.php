<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	require_once("../includes/validation_functions.php");
?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		$required_fields = array(
        "username",
        "password",
        "first_and_last_name",
        "phone",
        "email"
		);
		validate_presences($required_fields);
		
		$fields_with_max_lengths = array(
        "username" => 30
		);
		validate_max_lengths($fields_with_max_lengths);
		
		if (empty($errors)) {
			// Perform Create
			
			$username            = mysql_prep($_POST["username"]);
			$hashed_password     = password_encrypt($_POST["password"]);
			$first_and_last_name = mysql_prep($_POST["first_and_last_name"]);
			$phone               = mysql_prep($_POST["phone"]);
			$email               = mysql_prep($_POST["email"]);
			$FR = mysql_prep($_POST["FR"]);
			$EMT = mysql_prep($_POST["EMT"]);
			$EMTA = mysql_prep($_POST["EMTA"]);
			$EMTP = mysql_prep($_POST["EMTP"]);
			
			$query = "INSERT INTO users (";
			$query .= "  username, hashed_password, first_and_last_name, phone, administrator, email, FR, EMT, EMTA, EMTP";
			$query .= ") VALUES (";
			$query .= "  '{$username}', '{$hashed_password}', '{$first_and_last_name}', '{$phone}', '0', '{$email}', '{$FR}', '{$EMT}', '{$EMTA}', '{$EMTP}'";
			$query .= ")";
			$result = mysqli_query($connection, $query);
			
			if ($result) {
				// Success
				$_SESSION["message"] = "User created.";
				redirect_to("login.php");
				} else {
				// Failure
				$_SESSION["message"] = "User creation failed.";
			}
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php
	$layout_context = "public";
?>
<?php
	include("../includes/layouts/header.php");
?>
<div id="main">
	<div id="navigation">
		&nbsp;
	</div>
	<div id="page">
		<?php
			echo message();
		?>
		<?php
			echo form_errors($errors);
		?>
		
		<h2>Create Account</h2>
		<form action="account_creation.php" method="post">
			<p>Username:
				<input type="text" name="username" value="" />
			</p>
			<p>Password:
				<input type="password" name="password" value="" />
			</p>
			<p>First and Last Name:
				<input type="text" name="first_and_last_name" value="" />
			</p>
			<p>Phone:
				<input type="text" name="phone" value="" />
			</p>
			<p>Email:
				<input type="text" name="email" value="" />
			</p>
			<p>FR:
				<input type="radio" name="FR" value="0" /> No
				&nbsp;
				<input type="radio" name="FR" value="1" /> Yes
			</p>
			<p>EMT:
				<input type="radio" name="EMT" value="0" /> No
				&nbsp;
				<input type="radio" name="EMT" value="1" /> Yes
			</p>
			<p>EMTA:
				<input type="radio" name="EMTA" value="0" /> No
				&nbsp;
				<input type="radio" name="EMTA" value="1" /> Yes
			</p>
			<p>EMTP:
				<input type="radio" name="EMTP" value="0" /> No
				&nbsp;
				<input type="radio" name="EMTP" value="1" /> Yes
			</p>
			<input type="submit" name="submit" value="Create User" />
			&nbsp;
			<a href="login.php"><input type="button" name="cancel" value="Cancel" /></a>
		</form>
		<br />
		<br />
		<h3>Account Requirements:</h3>
		<li>Fields cannot be blank.</li>
		<li>Enter phone number without formatting. EX: 3175925920</li>
	</div>
</div>

<?php
	include("../includes/layouts/footer.php");
?>