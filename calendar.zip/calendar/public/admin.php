<?php
	require_once("../includes/session.php");
	require_once("../includes/functions.php");
	confirm_logged_in();
	$layout_context = "admin";
	include("../includes/layouts/header.php");
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Return to index</a>
		<br />
	</div>
	<div id="page">
		<h2>Admin Menu</h2>
		<p>Welcome to the admin area, <?php
			echo htmlentities($_SESSION["username"]);
		?>.</p>
		<ul>
			<li><a href="manage_content.php">Manage Website Content</a></li>
			<li><a href="manage_events.php">Manage Events</a></li>
			<li><a href="manage_users.php">Manage Users</a></li>
			<li><a href="manage_shifts.php">Manage Shifts</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
</div>

<?php
	include("../includes/layouts/footer.php");
?>
