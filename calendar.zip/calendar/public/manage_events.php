<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	confirm_logged_in();
	$event_set = find_all_events();
?>

<?php
	$layout_context = "admin";
	include("../includes/layouts/header.php"); 
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<?php echo message(); ?>
		<h2>Event Management</h2>
		<table>
			<tr>
				<th style="text-align: left; width: 200px;">Event Name</th>
				<th colspan="2" style="text-align: left;">Actions</th>
			</tr>
			<?php while($event = mysqli_fetch_assoc($event_set)) { ?>
				<tr>
					<td><?php echo htmlentities($event["event_name"]); ?></td>
					<td><a href="view_event.php?id=<?php echo urlencode($event["id"]); ?>">View</a></td>
					<td><a href="edit_event.php?id=<?php echo urlencode($event["id"]); ?>">Edit</a></td>
					<td><a href="delete_event.php?id=<?php echo urlencode($event["id"]); ?>" onclick="return confirm('Are you sure?');">Delete</a></td>
				</tr>
			<?php } ?>
		</table>
		<br />
	<a href="new_event.php">Add new event</a>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>