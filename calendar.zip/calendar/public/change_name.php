<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	require_once("../includes/validation_functions.php");
?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		$required_fields = array(
		"newname"
		);
		validate_presences($required_fields);
		
		
		if (empty($errors)) {
			$username = $_SESSION["username"];
			$new_name = mysql_prep($_POST["newname"]);
			
			$user = find_user_by_username($username);
			
			$query = "UPDATE users SET ";
			$query .= "first_and_last_name = '{$new_name}' ";
			$query .= "WHERE username = '{$username}' ";
			$query .= "LIMIT 1";
			$result = mysqli_query($connection, $query);
			
			if ($result && mysqli_affected_rows($connection) == 1) {
				// Success
				$_SESSION["message"] = "Name changed.";
				redirect_to("view_user.php");
				} else {
				// Failure
				$_SESSION["message"] = "Name change failed.";
			}
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php
	$layout_context = "public";
?>
<?php
	include("../includes/layouts/header.php");
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<?php
			echo message();
		?>
		<?php
			echo form_errors($errors);
		?>
		
		<h2>Change First and Last Name</h2>
		<form action="change_name.php" method="post">
			<p>Username: <?php
				echo $_SESSION["username"];
			?>
			</p>
			<p>New First and Last Name:
				<input type="text" name="newname" value="" />
			</p>
			<input type="submit" name="submit" value="Change Name" />
		</form>
	</div>
</div>

<?php
	include("../includes/layouts/footer.php");
?>
