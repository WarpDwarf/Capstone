<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	require_once("../includes/validation_functions.php");
?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		$required_fields = array(
		"oldpassword",
		"newpassword"
		);
		validate_presences($required_fields);
		
		
		if (empty($errors)) {
			$username     = $_SESSION["username"];
			$old_password = mysql_prep($_POST["oldpassword"]);
			$new_password = password_encrypt($_POST["newpassword"]);
			
			$correct_password = attempt_login($username, $old_password);
			$user             = find_user_by_username($username);
			
			if ($correct_password) {
				$query = "UPDATE users SET ";
				$query .= "hashed_password = '{$new_password}' ";
				$query .= "WHERE username = '{$username}' ";
				$query .= "LIMIT 1";
				$result = mysqli_query($connection, $query);
				} else {
				$result              = null;
				$_SESSION["message"] = "Username or Password incorrect.";
			}
			
			if ($result && mysqli_affected_rows($connection) == 1) {
				// Success
				$_SESSION["message"] = "Password changed.";
				redirect_to("view_user.php");
				} else {
				// Failure
				$_SESSION["message"] = "Password change failed.";
			}
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php
	$layout_context = "public";
?>
<?php
	include("../includes/layouts/header.php");
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<?php
			echo message();
		?>
		<?php
			echo form_errors($errors);
		?>
		
		<h2>Change Password</h2>
		<form action="change_password.php" method="post">
			<p>Username: <?php
				echo $_SESSION["username"];
			?>
			</p>
			<p>Old Password:
				<input type="password" name="oldpassword" value="" />
			</p>
			<p>New Password:
				<input type="password" name="newpassword" value="" />
			</p>
			<input type="submit" name="submit" value="Change Password" />
		</form>
	</div>
</div>

<?php
	include("../includes/layouts/footer.php");
?>
