<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php
	$user = find_user_by_username($_SESSION["username"]);
	
	if (!$user) {
		// Event ID was missing or invalid or 
		// event couldn't be found in database
		redirect_to("index.php");
	}
?>

<?php $layout_context = "public"; ?>
<?php include("../includes/layouts/header.php"); ?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<?php echo message(); ?>
		<h2>Account Details</h2>
		<p>Username: <?php echo htmlentities($user["username"]); ?></p>
		<p>First and Last Name: <?php echo htmlentities($user["first_and_last_name"]); ?></p>
		<p>Phone Number: <?php echo htmlentities($user["phone"]); ?></p>
		<p>Email: <?php echo htmlentities($user["email"]); ?></p>
		<p>Administrator: <?php if ($user["administrator"] == 0) {echo "No";} else echo "Yes"; ?>
		<p>FR: <?php if ($user["FR"] == 0) {echo "No";} else echo "Yes"; ?></p>
		<p>EMT: <?php if ($user["EMT"] == 0) {echo "No";} else echo "Yes"; ?></p>
		<p>EMTA: <?php if ($user["EMTA"] == 0) {echo "No";} else echo "Yes"; ?></p>
		<p>EMTP: <?php if ($user["EMTP"] == 0) {echo "No";} else echo "Yes"; ?></p>
		<br />
		<a href="change_name.php"><input type="button" name="new" value="Change Name" /></a>
		&nbsp;
		<a href="change_password.php"><input type="button" name="new" value="Change Password" /></a>
		&nbsp;
		<a href="change_phone.php"><input type="button" name="new" value="Change Phone Number" /></a>
		&nbsp;
		<a href="change_email.php"><input type="button" name="new" value="Change Email" /></a>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
