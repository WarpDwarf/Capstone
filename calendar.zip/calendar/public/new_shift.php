<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		$required_fields = array("date");
		validate_presences($required_fields);
		
		if (empty($errors)) {
			// Perform Create
			
			$date = mysql_prep($_POST["date"]);
			$D = mysql_prep($_POST["D"]);
			$O = mysql_prep($_POST["O"]);
			$FF1 = mysql_prep($_POST["FF1"]);
			$FF2 = mysql_prep($_POST["FF2"]);
			
			$query  = "INSERT INTO shifts (";
			$query .= "  date, D, O, FF1, FF2";
			$query .= ") VALUES (";
			$query .= "  '{$date}', '{$D}', '{$O}', '{$FF1}', '{$FF2}'";
			$query .= ")";
			$result = mysqli_query($connection, $query);
			
			if ($result) {
				// Success
				$_SESSION["message"] = "Shift created.";
				redirect_to("manage_shifts.php");
				} else {
				// Failure
				$_SESSION["message"] = "Shift creation failed.";
			}
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>
<div id="main">
	<div id="navigation">
		&nbsp;
	</div>
	<div id="page">
		<?php echo message(); ?>
		<?php echo form_errors($errors); ?>
		
		<h2>Create Shift</h2>
		<form action="new_shift.php" method="post">
			<p>Date:
				<input type="text" name="date" value="" />
			</p>
			<p>D:
				<input type="text" name="D" value="" />
			</p>
			<p>O:
				<input type="text" name="O" value="" />
			</p>
			<p>FF1:
				<input type="text" name="FF1" value="" />
			</p>
			<p>FF2:
				<input type="text" name="FF2" value="" />
			</p>
			<input type="submit" name="submit" value="Create Shift" />
			&nbsp;
			<a href="manage_shifts.php"><input type="button" name="cancel" value="Cancel" /></a>
		</form>
		<br />
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
