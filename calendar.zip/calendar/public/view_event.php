<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php
	$event = find_event_by_id($_GET["id"]);
	
	if (!$event) {
		// Event ID was missing or invalid or 
		// event couldn't be found in database
		redirect_to("index.php");
	}
?>

<?php 
	$layout_context = "public";
	include("../includes/layouts/header.php");
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
		<br />
		<a href="view_events.php">&laquo; Back to events</a>
		<br />
	</div>
	<div id="page">
		<?php echo message(); ?>
		
		<h2>View Event: <?php echo htmlentities($event["event_name"]); ?></h2>
		<p>Event Name: <?php echo htmlentities($event["event_name"]); ?></p>
		<p>Location: <?php echo htmlentities($event["location"]); ?></p>
		<p>Date: <?php echo htmlentities($event["event_date"]); ?></p>
		<p>Time: <?php echo htmlentities($event["event_time"]); ?></p>
		<p>Number of volunteers requested: <?php echo htmlentities($event["number_requested"]); ?></p>
		<p>Number of volunteers joined: <?php echo htmlentities($event["number_joined"]); ?></p>
		<p>Users: <?php echo htmlentities($event["users_joined"]); ?></p>
		<p>Description: <?php echo htmlentities($event["description"]); ?></p>
		<br />
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
