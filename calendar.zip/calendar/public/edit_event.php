<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php
	$event = find_event_by_id($_GET["id"]);
	
	if (!$event) {
		// Event ID was missing or invalid or 
		// event couldn't be found in database
		redirect_to("manage_events.php");
	}
?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		//$required_fields = array("username", "password", "first_and_last_name", "phone", "administrator", "email");
		//validate_presences($required_fields);
		
		//$fields_with_max_lengths = array("username" => 30);
		//validate_max_lengths($fields_with_max_lengths);
		
		if (empty($errors)) {
			// Perform Update
			
			$id = $event["id"];
			$event_name = mysql_prep($_POST["event_name"]);
			$location = mysql_prep($_POST["location"]);
			$event_date = mysql_prep($_POST["event_date"]);
			$event_time = mysql_prep($_POST["event_time"]);
			$number_requested = mysql_prep($_POST["number_requested"]);
			$description = mysql_prep($_POST["description"]);
			
			$query  = "UPDATE events SET ";
			$query .= "event_name = '{$event_name}', ";
			$query .= "location = '{$location}', ";
			$query .= "event_date = '{$event_date}', ";
			$query .= "event_time = '{$event_time}', ";
			$query .= "number_requested = '{$number_requested}', ";
			$query .= "description = '{$description}' ";
			$query .= "WHERE id = '{$id}' ";
			$query .= "LIMIT 1";
			$result = mysqli_query($connection, $query);
			
			if ($result && mysqli_affected_rows($connection) == 1) {
				// Success
				$_SESSION["message"] = "Event updated.";
				redirect_to("manage_events.php");
				} else {
				// Failure
				$_SESSION["message"] = "Event update failed, or no changes detected.";
			}
			
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<?php echo message(); ?>
		<?php echo form_errors($errors); ?>
		
		<h2>Edit Event: <?php echo htmlentities($event["event_name"]); ?></h2>
		<form action="edit_event.php?id=<?php echo urlencode($event["id"]); ?>" method="post">
			<p>Event Name:
				<input type="text" name="event_name" value="<?php echo htmlentities($event["event_name"]); ?>" />
			</p>
			<p>Location:
				<input type="text" name="location" value="<?php echo htmlentities($event["location"]); ?>" />
			</p>
			<p>Date:
				<input type="text" name="event_date" value="<?php echo htmlentities($event["event_date"]); ?>" />
			</p>
			<p>Time:
				<input type="text" name="event_time" value="<?php echo htmlentities($event["event_time"]); ?>" />
			</p>
			<p>Number of volunteers requested:
				<input type="text" name="number_requested" value="<?php echo htmlentities($event["number_requested"]); ?>" />
			</p>
			<p>Description:
				<textarea name="description" rows="15" cols="60"><?php echo htmlentities($event["description"]); ?></textarea>
			</p>
			<input type="submit" name="submit" value="Edit Event" />
		</form>
		<br />
		<a href="manage_events.php"><input type="button" name="cancel" value="Cancel" /></a>
		<h3>Event Requirements:</h3>
		<li>Fields cannot be blank.</li>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
