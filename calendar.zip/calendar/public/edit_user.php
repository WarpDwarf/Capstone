<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php
	$user = find_user_by_id($_GET["id"]);
	
	if (!$user) {
		// user ID was missing or invalid or 
		// user couldn't be found in database
		redirect_to("manage_users.php");
	}
?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		$required_fields = array("username", "first_and_last_name", "phone", "email");
		validate_presences($required_fields);
		
		$fields_with_max_lengths = array("username" => 30);
		validate_max_lengths($fields_with_max_lengths);
		
		if (empty($errors)) {
			
			// Perform Update
			
			$id = $user["id"];
			$username = mysql_prep($_POST["username"]);
			$hashed_password = password_encrypt($_POST["password"]);
			$first_and_last_name = mysql_prep($_POST["first_and_last_name"]);
			$phone = mysql_prep($_POST["phone"]);
			$administrator = mysql_prep($_POST["administrator"]);
			$email = mysql_prep($_POST["email"]);
			$FR = mysql_prep($_POST["FR"]);
			$EMT = mysql_prep($_POST["EMT"]);
			$EMTA = mysql_prep($_POST["EMTA"]);
			$EMTP = mysql_prep($_POST["EMTP"]);
			
			$query  = "UPDATE users SET ";
			$query .= "username = '{$username}', ";
			$query .= "hashed_password = '{$hashed_password}', ";
			$query .= "first_and_last_name = '{$first_and_last_name}', ";
			$query .= "phone = '{$phone}', ";
			$query .= "administrator = '{$administrator}', ";
			$query .= "email = '{$email}', ";
			$query .= "FR = '{$FR}', ";
			$query .= "EMT = '{$EMT}', ";
			$query .= "EMTA = '{$EMTA}', ";
			$query .= "EMTP = '{$EMTP}' ";
			$query .= "WHERE id = '{$id}' ";
			$query .= "LIMIT 1";
			$result = mysqli_query($connection, $query);
			
			if ($result && mysqli_affected_rows($connection) == 1) {
				// Success
				$_SESSION["message"] = "User updated.";
				redirect_to("manage_users.php");
				} else {
				// Failure
				$_SESSION["message"] = "User update failed.";
			}
			
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>

<div id="main">
	<div id="navigation">
		&nbsp;
	</div>
	<div id="page">
		<?php echo message(); ?>
		<?php echo form_errors($errors); ?>
		
		<h2>Edit User: <?php echo htmlentities($user["username"]); ?></h2>
		<form action="edit_user.php?id=<?php echo urlencode($user["id"]); ?>" method="post">
			<p>Username:
				<input type="text" name="username" value="<?php echo htmlentities($user["username"]); ?>" />
			</p>
			<p>Password:
				<input type="password" name="password" value="" />
			</p>
			<p>First and Last Name:
				<input type="text" name="first_and_last_name" value="<?php echo htmlentities($user["first_and_last_name"]); ?>" />
			</p>
			<p>Phone:
				<input type="text" name="phone" value="<?php echo htmlentities($user["phone"]); ?>" />
			</p>
			<p>Email:
				<input type="text" name="email" value="<?php echo htmlentities($user["email"]); ?>" />
			</p>
			<p>Administrator:
				<input type="radio" name="administrator" value="0" /> No
				&nbsp;
				<input type="radio" name="administrator" value="1" /> Yes
			</p>
			<p>FR:
				<input type="radio" name="FR" value="0" /> No
				&nbsp;
				<input type="radio" name="FR" value="1" /> Yes
			</p>
			<p>EMT:
				<input type="radio" name="EMT" value="0" /> No
				&nbsp;
				<input type="radio" name="EMT" value="1" /> Yes
			</p>
			<p>EMTA:
				<input type="radio" name="EMTA" value="0" /> No
				&nbsp;
				<input type="radio" name="EMTA" value="1" /> Yes
			</p>
			<p>EMTP:
				<input type="radio" name="EMTP" value="0" /> No
				&nbsp;
				<input type="radio" name="EMTP" value="1" /> Yes
			</p>
			<input type="submit" name="submit" value="Edit User" />
		</form>
		<br />
		<a href="manage_users.php"><input type="button" name="cancel" value="Cancel" /></a>
		<h3>Account Requirements:</h3>
		<li>Fields cannot be blank.</li>
		<li>Administrator and certification options must be chosen.</li>
		<li>Enter phone number without formatting. EX: 3175925920</li>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
