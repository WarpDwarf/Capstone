<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php find_selected_page(); ?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		$required_fields = array("event_name", "location", "event_date", "event_time", "number_requested");
		validate_presences($required_fields);
		
		//$fields_with_max_lengths = array("event_name" => 30);
		//validate_max_lengths($fields_with_max_lengths);
		
		if (empty($errors)) {
			// Perform Create
			
			$event_name = mysql_prep($_POST["event_name"]);
			$location = mysql_prep($_POST["location"]);
			$event_date = mysql_prep($_POST["event_date"]);
			$event_time = mysql_prep($_POST["event_time"]);
			$number_requested = mysql_prep($_POST["number_requested"]);
			$description = mysql_prep($_POST["description"]);
			
			$query  = "INSERT INTO events (";
			$query .= "  event_name, location, event_date, event_time, number_requested, description";
			$query .= ") VALUES (";
			$query .= "  '{$event_name}', '{$location}', '{$event_date}', '{$event_time}', '{$number_requested}', '{$description}')";
			$result = mysqli_query($connection, $query);
			
			if ($result) {
				// Success
				$_SESSION["message"] = "Event created.";
				redirect_to("manage_events.php");
				} else {
				// Failure
				$_SESSION["message"] = "Event creation failed.";
			}
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
?>

<?php $layout_context = "public"; ?>
<?php include("../includes/layouts/header.php"); ?>
<div id="main">
	<div id="navigation">
		<?php echo navigation($current_subject, $current_page); ?>
	</div>
	<div id="page">
		<?php echo message(); ?>
		<?php echo form_errors($errors); ?>
		
		<h2>Create Event</h2>
		<form action="new_event.php" method="post">
			<p>Event name:
				<input type="text" name="event_name" value="" />
			</p>
			<p>Location:
				<input type="text" name="location" value="" />
			</p>
			<p>Date:
				<input type="text" name="event_date" value="" />
			</p>
			<p>Time:
				<input type="text" name="event_time" value="" />
			</p>
			<p>Number of volunteers requested:
				<input type="text" name="number_requested" value="" />
			</p>
			<p>Description:<br />
				<textarea name="description" rows="15" cols="80"></textarea>
			</p>
			<input type="submit" name="submit" value="Create Event" />
		</form>
		<br />
		<a href="manage_events.php">Cancel</a>
	</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>