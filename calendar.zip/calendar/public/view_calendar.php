<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in(); ?>

<?php include("../includes/layouts/header.php"); ?>
<?php include("calendar.php");?>
<?php find_selected_page(true); ?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<br />
		<?php echo draw_calendar($month,$year,$events); ?>
		<br />
	</div>
	
<?php include("../includes/layouts/footer.php"); ?>