<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	require_once("../includes/validation_functions.php");
?>

<?php
	if (isset($_POST['submit'])) {
		// Process the form
		
		// validations
		$required_fields = array(
		"newphone"
		);
		validate_presences($required_fields);
		
		
		if (empty($errors)) {
			$username = $_SESSION["username"];
			$new_phone = mysql_prep($_POST["newphone"]);
			
			$user = find_user_by_username($username);
			
			$query = "UPDATE users SET ";
			$query .= "phone = '{$new_phone}' ";
			$query .= "WHERE username = '{$username}' ";
			$query .= "LIMIT 1";
			$result = mysqli_query($connection, $query);
			
			if ($result && mysqli_affected_rows($connection) == 1) {
				// Success
				$_SESSION["message"] = "Phone number changed.";
				redirect_to("view_user.php");
				} else {
				// Failure
				$_SESSION["message"] = "Phone number change failed.";
			}
		}
		} else {
		// This is probably a GET request
		
	} // end: if (isset($_POST['submit']))
	
?>

<?php
	$layout_context = "public";
?>
<?php
	include("../includes/layouts/header.php");
?>

<div id="main">
	<div id="navigation">
		<br />
		<a href="index.php">&laquo; Main menu</a>
		<br />
	</div>
	<div id="page">
		<?php
			echo message();
		?>
		<?php
			echo form_errors($errors);
		?>
		
		<h2>Change Phone Number</h2>
		<form action="change_phone.php" method="post">
			<p>Username: <?php
				echo $_SESSION["username"];
			?>
			</p>
			<p>New Phone Number:
				<input type="text" name="newphone" value="" />
			</p>
			<input type="submit" name="submit" value="Change Phone" />
		</form>
	</div>
</div>

<?php
	include("../includes/layouts/footer.php");
?>
