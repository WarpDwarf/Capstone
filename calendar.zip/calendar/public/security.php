<?php
	$salt = md5(uniqid(mt_rand(), true));
	
	$format_and_salt = $format_string . $salt;
	
	$hashed_password = crypt($password, $format_and_salt);
?>