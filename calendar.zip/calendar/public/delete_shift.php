<?php
	require_once("../includes/session.php");
	require_once("../includes/db_connection.php");
	require_once("../includes/functions.php");
	confirm_logged_in(); 
?>

<?php
	$shift = find_shift_by_id($_GET["id"]);
	
	if (!$shift) {
		// Shift ID was missing or invalid or 
		// shift couldn't be found in database
		redirect_to("manage_shifts.php");
	}
	
	$id = $shift["id"];
	$query = "DELETE FROM shifts WHERE id = {$id} LIMIT 1";
	$result = mysqli_query($connection, $query);
	
	if ($result && mysqli_affected_rows($connection) == 1) {
		// Success
		$_SESSION["message"] = "Shift deleted.";
		redirect_to("manage_shifts.php");
		} else {
		// Failure
		$_SESSION["message"] = "Shift deletion failed.";
	}
?>
